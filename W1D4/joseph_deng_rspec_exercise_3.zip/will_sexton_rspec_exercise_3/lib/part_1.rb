require "byebug"
def is_prime?(num)
(2...num).each {|factor| return false if num % factor == 0}
num >= 2
end

def nth_prime(num)
    count = 0; #counting prime numbers
    i = 1 # number checked for primeness
    while count < num
        i += 1
        if is_prime?(i)
            count += 1
        end
    end
i

end

def prime_range(min,max)
    (min..max).select {|n| is_prime?(n) }
end

