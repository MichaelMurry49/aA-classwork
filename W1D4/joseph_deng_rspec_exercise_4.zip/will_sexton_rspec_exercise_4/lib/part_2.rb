def proper_factors(num)
    (1...num).select { |fact| num % fact == 0 }
end

def aliquot_sum(num)
    proper_factors(num).sum
end

def perfect_number?(num)
    num == aliquot_sum(num)
end

def ideal_numbers(num)
    arr = []
    i = 1
    while arr.length < num
        arr.push(i) if perfect_number?(i)
        i += 1
    end
    arr
end