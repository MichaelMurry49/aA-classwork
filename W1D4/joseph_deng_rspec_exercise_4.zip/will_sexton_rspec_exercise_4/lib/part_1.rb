def my_reject(arr, &proc)
    arr.select {|ele| !proc.call(ele)}
end

def my_one?(arr, &proc)
    counter = 0
    arr.each {|ele| counter += 1 if proc.call(ele)}
    counter == 1
end

def hash_select(hash, &proc)
    new_hash = {}
    hash.each {|k,v| new_hash[k] = v if proc.call(k,v)}
    new_hash
end

def xor_select(array, proc1, proc2)
    array.select { |ele| (proc1.call(ele) || proc2.call(ele)) && !(proc1.call(ele) && proc2.call(ele))}
end

def proc_count(val, array)
    array.map{|proc| proc.call(val)}.count(true)
end
