require_relative 'card'

class Board
    attr_reader :grid

    def initialize(n)
        @grid = Array.new(n) { Array.new(n) }
    end

    def populate(chars)
        chars.each do |char|
            cards_to_place = 2
            while cards_to_place > 0  
                row_i, col_i = rand(@grid.length), rand(@grid.length)
                unless @grid[row_i][col_i]
                    @grid[row_i][col_i] = Card.new(char)
                    cards_to_place -= 1
                end
            end
        end
    end

    def render
        # @grid[0].each_with_index { |ele, i| p i.to_s + ' '}
        # @grid[0].each_with_index { |ele, i| puts i.to_s + ' '}
        puts '  ' + (0...@grid.length).to_a.map(&:to_s).join(' ')
        @grid.each_with_index do |row, i|
            print i 
            row.each do |card|
                if card.face_up
                    print " #{card.face_val}"
                else
                    print "  "
                end
            end
            puts
        end
    end

    def won?
        @grid.all? { |row| row.all? { |card| card.face_up } }
    end

    def reveal(guessed_pos)
        x, y = guessed_pos
        card = @grid[x][y]
        card.reveal
        card.face_val
    end
end

# card1 = Card.new('P')
# card2 = Card.new('L')
# board = Board.new(2)
# board.populate([card1, card2])
# board.render