require_relative 'board'
require_relative 'card'
require 'byebug'

class Game
    def initialize(n)
        raise "Invalid board length, must be even." if n.odd?
        @board = Board.new(n)
        @board.populate(Card.random_cards(n * n / 2))
        @previous_guess = nil
        @players = [HumanPlayer.new, ComputerPlayer.new]
        @curr_player = @players[0]
    end

    def over?
        @board.won?
    end

    def make_guess(pos)
        x, y = pos[0], pos[1]
        unless @previous_guess
            @board.reveal(pos)
            @previous_guess = @board.grid[x][y]
        else
            # debugger
            if @previous_guess.face_val == @board.grid[x][y].face_val
                @previous_guess.reveal
                @board.reveal(pos)
                system('clear')
                @board.render
                p 'you have a match'
                sleep(3)
                @previous_guess = nil
            else
                @board.reveal(pos)
                system('clear')
                @board.render
                p 'try again'
                sleep(3)
                @board.grid[x][y].hide
                @previous_guess.hide
                @previous_guess = nil

            end
        end
    end

    def play
        @board.render
        sleep(3)
        system("clear")
        @board.grid.each { |row| row.each { |card| card.hide } }
        
        while !over?
            @board.render
            make_guess(@player.prompt)
            @board.render
            system("clear")
        end
    end
end

g = Game.new(4)
g.play