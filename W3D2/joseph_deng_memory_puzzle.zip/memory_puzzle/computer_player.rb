class ComputerPlayer
    def initialize
        @known_cards = {}
        @matched_cards = []
    end
    
    def receive_revealed_card(pos, face_val)
        @known_cards[pos] = face_val
    end

    def receive_match(pos_1, pos_2)
        @matched_cards << [pos_1, pos_2]
    end

    def prompt
        if !@matched_cards.empty

            return matched_cards[0]
        end
    end
end