class Card 
    attr_reader :face_up, :face_val

    def initialize(face_val)
        @face_val = face_val
        @face_up = true
    end

    def self.random_cards(n)
        ('A'..'Z').to_a.sample(n)
    end

    def hide
        @face_up = false
    end

    def reveal
        @face_up = true
    end

    def to_s
        @face_val.to_s
    end

    def ==(card)
        @face_val == card.face_val
    end
end