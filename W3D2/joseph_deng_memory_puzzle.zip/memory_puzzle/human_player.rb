class HumanPlayer
    
    def prompt
        p 'Enter a position of the card you like to flip. (e.g. 2,3)'
        gets.chomp.split(',').map(&:to_i)
    end
end